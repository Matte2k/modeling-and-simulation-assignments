%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Hrishi Shah
% Generalized Newton Raphson Method
% Readme
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
There are two methods to approach this problem.
1) For running outside a loop, 
	a) write a file(temp12345.m) with all required variables (done by newton_raphson.m)
	and
	b) run it using another file (newton_raphson.m).
   Everything is automatic. Example is in example_inputs.m
2) For running in a loop, 
	a) create the file (temp12345.m) once 
	or
	b) substitute in method2.m 
   and then call it in a loop.